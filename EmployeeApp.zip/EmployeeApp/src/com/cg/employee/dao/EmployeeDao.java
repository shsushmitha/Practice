package com.cg.employee.dao;

import java.util.Collection;
import java.util.List;

import com.cg.employee.bean.Employee;
import com.cg.employee.exception.EmployeeException;

public interface EmployeeDao {
	Collection<Employee> getAllEmployees() throws EmployeeException;
	Employee getEmployeeById(int id) throws EmployeeException;
	boolean deleteEmployee(int id) throws EmployeeException;
	int addEmployee(Employee emp) throws EmployeeException;
	Collection<Employee> getEmployeeBySalary(double salary) throws EmployeeException;
	int updateEmployee(Employee emp) throws EmployeeException;
}
