package com.cg.employee.dao;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

import com.cg.employee.bean.Employee;
import com.cg.employee.db.EmployeeDB;
import com.cg.employee.exception.EmployeeException;

/**
 * Class : EmployeeDaoImpl Author: Sushmitha Date: 30th June, 2018
 * 
 * Purpose: Data manipulation of Associated data store No. of methods: 5
 * 
 */

public class EmployeeDaoImpl implements EmployeeDao {
	static HashMap<Integer, Employee> empMap = EmployeeDB.getEmployeeMap();

	/**
	 * Method Name: getAllEmployees Parameters: Nil Return type: Collection of
	 * eEmployees Purpose: Retrieves all the data from the underlying data store
	 * 
	 * Author: Sushmitha Date of Creation: 20th June, 2018
	 * 
	 * Last Modified Date: 20th June, 2018
	 */
	@Override
	public Collection<Employee> getAllEmployees() throws EmployeeException {
		try {
			Collection<Employee> employees = (Collection<Employee>) empMap.values();
			return employees;
		} catch (Exception ex) {
			throw new EmployeeException(ex.getMessage());
		}
	}

	@Override
	public Employee getEmployeeById(int id) throws EmployeeException {
		try {
			Employee employee = empMap.get(id);

			if (employee == null) {
				throw new EmployeeException("Employee with Id:" + id + "Not available in the database");
			}
			return employee;
		} catch (Exception ex) {
			throw new EmployeeException(ex.getMessage());
		}

	}

	@Override
	public boolean deleteEmployee(int id) throws EmployeeException {
		try {
			Employee emp = empMap.remove(id);
			if (emp == null) {
				throw new EmployeeException("Employee with Id:" + id + "Not available in the database");
			}
		} catch (Exception ex) {
			throw new EmployeeException(ex.getMessage());
		}
		return true;
	}

	@Override
	public int addEmployee(Employee emp) throws EmployeeException {
		try {
			Employee e = empMap.get(emp.getId());
			if (e != null) {
				throw new EmployeeException("Employee with Id" + emp.getId() + "already exists");
			} else {
				empMap.put(emp.getId(), emp);
			}
		} catch (Exception ex) {
			throw new EmployeeException(ex.getMessage());
		}
		return emp.getId();
	}

	@Override
	public Collection<Employee> getEmployeeBySalary(double salary) throws EmployeeException {
		List<Employee> employees = empMap.values().stream().filter(x -> x.getSalary() >= salary)
				.collect(Collectors.toList());
		return employees;
	}

	@Override
	public int updateEmployee(Employee emp) throws EmployeeException {
		try {
			Employee e = empMap.get(emp.getId());
			
				empMap.replace(emp.getId(), emp);
			
		} catch (Exception ex) {
			throw new EmployeeException(ex.getMessage());
		}
		return emp.getId();
		
	}

}

