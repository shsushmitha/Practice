package com.cg.employee.db;

import java.util.HashMap;

import com.cg.employee.bean.Employee;

public class EmployeeDB {
	private static HashMap<Integer, Employee> employeeMap = new HashMap<Integer, Employee>();
	
	static {
		employeeMap.put(1001, new Employee(1001,"Mark","9999999999","mark@gmail.com",89000));
		employeeMap.put(1002, new Employee(1002,"Pam","8888888888","pam@outlook.com",78000));
		employeeMap.put(1003, new Employee(1003,"Sara","7777777777","sara@ymail.com",67000));
		employeeMap.put(1004, new Employee(1004,"Ben","6666666666","ben@gmail.com",59000));
		employeeMap.put(1005, new Employee(1005,"Anil","9898989898","anil@gmail.com",78909));
		employeeMap.put(1006, new Employee(1006,"Sunil","67676767679","sunil@gmail.com",60000));
	}
	
	public static HashMap<Integer, Employee> getEmployeeMap() {
		return employeeMap;
	}
	

	
}
