package com.cg.employee.service;

import java.util.Collection;
import java.util.List;

import com.cg.employee.bean.Employee;
import com.cg.employee.dao.EmployeeDao;
import com.cg.employee.dao.EmployeeDaoImpl;
import com.cg.employee.exception.EmployeeException;

public class EmployeeServiceImpl implements Employeeservice {
	EmployeeDao employeeDao = new EmployeeDaoImpl();

	@Override
	public Collection<Employee> getAllEmployees() throws EmployeeException {
		// TODO Auto-generated method stub
		return employeeDao.getAllEmployees();

	}

	@Override
	public Employee getEmployeeById(int id) throws EmployeeException {

		return employeeDao.getEmployeeById(id);
	}

	@Override
	public boolean deleteEmployee(int id) throws EmployeeException {

		return employeeDao.deleteEmployee(id);
	}

	@Override
	public boolean validateEmployee(Employee emp) throws EmployeeException {
		if (validateName(emp.getName()) && validateMobile(emp.getMobile()) && validateEmail(emp.getEmail())) {
			return true;
		}
		return false;
	}

	private boolean validateName(String name) throws EmployeeException {
		if (name.isEmpty() || name == null) {
			throw new EmployeeException("Employee Name cannot be empty");
		} else {
			if (!name.matches("[A-Z][A-Za-z ]{2,}")) {
				throw new EmployeeException(
						"Name should start with a Capital letter followed by minimum of 2 alphabets");
			}
		}
		return true;
	}

	private boolean validateMobile(String mobile) throws EmployeeException {

		if (mobile.isEmpty() || mobile == null) {
			throw new EmployeeException("Mobile Number is mandatory");

		} else {
			if (!mobile.matches("\\d{10}")) {
				throw new EmployeeException("Mobile number should contain only 10 digits");
			}
		}
		return true;
	}
	
	private boolean validateEmail(String email) throws EmployeeException {
		if(!email.matches("[A-Za-z0-9_]+@+[a-z]+\\.com")) {
			throw new EmployeeException("Please enter a valid email Id");
		}
		return true;
	}

	@Override
	public int addEmployee(Employee emp) throws EmployeeException {
		
		return employeeDao.addEmployee(emp);
	}

	@Override
	public Collection<Employee> getEmployeeBySalary(double salary) throws EmployeeException {
		
		return employeeDao.getEmployeeBySalary(salary);
	}

	@Override
	public int updateEmployee(Employee emp) throws EmployeeException {
		// TODO Auto-generated method stub
		return employeeDao.updateEmployee(emp);
	}



}
