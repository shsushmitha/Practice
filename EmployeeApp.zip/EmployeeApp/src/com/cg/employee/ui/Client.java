package com.cg.employee.ui;

import java.util.Collection;
import java.util.Scanner;

import com.cg.employee.bean.Employee;
import com.cg.employee.exception.EmployeeException;
import com.cg.employee.service.EmployeeServiceImpl;
import com.cg.employee.service.Employeeservice;

public class Client {
	Employeeservice employeeservice = new EmployeeServiceImpl();
	Scanner scan = new Scanner(System.in);

	public static void main(String[] args) {
		String option = null;

		Client c = new Client();
		while (true) {
			System.out.println("========Employee Management System========");
			System.out.println("1. Add an employee");
			System.out.println("2. Display All Employees");
			System.out.println("3. Display an Employee");
			System.out.println("4. Delete an Employee");
			System.out.println("5. Update an Employee");
			System.out.println("6. Exit");
			System.out.println("7. View employee based on salary");
			System.out.println("Choose an option");
			option = c.scan.nextLine();
			switch (option) {
			case "1":
				c.addEmployee();
				break;
			case "2":
				c.getAllEmployees();
				break;
			case "3":
				c.getEmployeeById();
				break;
			case "4":
				c.deleteEmployee();
				break;
			case "5":
				c.updateEmployee();
				break;
			case "6":
				System.exit(0);
			default:
				System.err.println("Invalid Option Choose from 1 to 6");
				System.out.println();
				break;
			case "7":
				c.getEmployeeBySalary();
				break;
			}
		}

	}

	public void getAllEmployees() {
		try {
			Collection<Employee> employees = employeeservice.getAllEmployees();
			//employees.stream().forEach(System.out::println);
			employees.stream().sorted((x,y)->x.getSalary()>y.getSalary()?-1:x.getSalary()<y.getSalary()?1:0).forEach(System.out::println);;
		} catch (EmployeeException e) {
			System.err.println("An error occured:" + e.getMessage());
		}
	}

	public void getEmployeeById() {
		System.out.println("Enter Employee Id");
		String id = scan.nextLine();
		try {
			int empId = Integer.parseInt(id);

			Employee emp = employeeservice.getEmployeeById(empId);
			System.out.println(emp);
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			System.err.println("An error occured" + e.getMessage());
		}

	}

	public void deleteEmployee() {
		System.out.println("Enter Employee Id");
		String id = scan.nextLine();
		try {
			int empId = Integer.parseInt(id);

			boolean result = employeeservice.deleteEmployee(empId);
			if (result) {
				System.out.println("Employee with Id " + empId + " Successfully deleted");
			}
		} catch (EmployeeException ex) {
			System.err.println("An error occured" + ex.getMessage());
		}
	}

	public void addEmployee() {
		Employee emp = new Employee();
		System.out.println("Enter Employee Id");
		emp.setId(Integer.parseInt(scan.nextLine()));

		System.out.println("Enter employee name");
		emp.setName(scan.nextLine());

		System.out.println("Enter mobile");
		emp.setMobile(scan.nextLine());

		System.out.println("Enter Email");
		emp.setEmail(scan.nextLine());

		System.out.println("Enter Salary");
		emp.setSalary(Double.parseDouble(scan.nextLine()));
		try {
			boolean result = employeeservice.validateEmployee(emp);
			if (result) {
				int ret = employeeservice.addEmployee(emp);
				System.out.println("Employee with Id " + ret + " added successfully");
			}
		} catch (EmployeeException e) {
			System.out.println();
			System.err.println("An error occured" + e.getMessage());
			System.out.println();
		}
		
	}
	
	public void updateEmployee() {
		Employee emp = new Employee();
		System.out.println("Enter Employee Id");
		emp.setId(Integer.parseInt(scan.nextLine()));

		System.out.println("Enter employee name");
		emp.setName(scan.nextLine());

		System.out.println("Enter mobile");
		emp.setMobile(scan.nextLine());

		System.out.println("Enter Email");
		emp.setEmail(scan.nextLine());

		System.out.println("Enter Salary");
		emp.setSalary(Double.parseDouble(scan.nextLine()));
		try {
			boolean result = employeeservice.validateEmployee(emp);
			if (result) {
				int ret = employeeservice.updateEmployee(emp);
				System.out.println("Employee with Id " + ret + " added successfully");
			}
		} catch (EmployeeException e) {
			System.out.println();
			System.err.println("An error occured" + e.getMessage());
			System.out.println();
		}
	}
	
	

	public void getEmployeeBySalary() {
		System.out.println("Enter salary");
		try {
			double salary = Double.parseDouble(scan.nextLine());
			Collection<Employee> employees = employeeservice.getEmployeeBySalary(salary);
			employees.forEach(System.out::println);
		} catch (EmployeeException e) {
			System.out.println();
			System.err.println("An error occured" + e.getMessage());
			System.out.println();
		}
		catch(Exception e) {
			System.out.println();
			System.err.println("An error occured" + e.getMessage());
			System.out.println();
		}
	}
	
	

}
