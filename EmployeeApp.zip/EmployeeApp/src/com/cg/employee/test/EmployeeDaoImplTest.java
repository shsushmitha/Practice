package com.cg.employee.test;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Collection;

import org.junit.Test;

import com.cg.employee.bean.Employee;
import com.cg.employee.dao.EmployeeDao;
import com.cg.employee.dao.EmployeeDaoImpl;
import com.cg.employee.exception.EmployeeException;

public class EmployeeDaoImplTest {

	EmployeeDao dao = new EmployeeDaoImpl();

	@Test
	public void testGetAllEmployees() {
		try {
			Collection<Employee> employees = dao.getAllEmployees();
			assertEquals(6, employees.size());

		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void testGetEmployeeById() {
		try {
			Employee emp = dao.getEmployeeById(1002);
			assertNotNull(emp);
			Employee emp1 = dao.getEmployeeById(2000);
			assertNull(emp1);
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
	}

	@Test
	public void testDeleteEmployee() {
		try {
			boolean b = dao.deleteEmployee(1001);
			assertTrue(true);
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void testAddEmployee() {
		Employee emp = new Employee();
		emp.setId(1009);
		emp.setName("Chinnu");
		emp.setMobile("9999999999");
		emp.setEmail("abc@gmail.com");
		emp.setSalary(50000);
		try {
			dao.addEmployee(emp);
			Employee e = dao.getEmployeeById(1009);
			assertNotNull(e);
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
	}

	@Test
	public void testUpdateEmployee() {
		Employee emp = new Employee();
		emp.setId(1009);
		emp.setName("Chinnu");
		emp.setMobile("9999999999");
		emp.setEmail("abc@gmail.com");
		emp.setSalary(50000);
		try {
			dao.updateEmployee(emp);
			Employee e = dao.getEmployeeById(1009);
			assertNotNull(e);
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
	}
}
