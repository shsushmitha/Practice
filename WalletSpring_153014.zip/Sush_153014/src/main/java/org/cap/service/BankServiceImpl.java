package org.cap.service;


import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.cap.dao.IBankDao;
import org.cap.model.Account;
import org.cap.model.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service("bankService")
public class BankServiceImpl implements IBankService {
    @Autowired
    private IBankDao bankDao;
	@Override
	public boolean validate(int username, String password) {
		// TODO Auto-generated method stub
			return bankDao.validate(username,password);
	}
	@Override
	public void createAccount(Account account) {
		bankDao.createAccount(account);
		
	}
	@Override
	public String getUserName() {
		
		return bankDao.getUserName();
	}
	@Override
	public List<Long> getAccountNumbers() {
		// TODO Auto-generated method stub
		return bankDao.getAccountNumbers();
	}
	@Override
	public void depWithAccount(Transaction transaction) {
		bankDao.depWithAccount(transaction);
		
	}
	@Override
	public List<Account> getAllAccountsOfCustomer() {
		
		return bankDao.getAllAccountsOfCustomer();
	}
	@Override
	public List<Account> getAccountWithBalance(){
		
		String str="from Transaction tx where tx.customer.customerId=:custId and tx.transactionType='debit'";
				Map<Account, Double> deMap = bankDao.getAmoutCrDe(str);
		
			String str1="from Transaction tx where tx.customer.customerId=:custId and tx.transactionType='credit'";
			Map<Account, Double> crMap = bankDao.getAmoutCrDe(str1);
				

			List<Account> accounts=bankDao.getAllAccountsOfCustomer();
			Iterator<Account> iterator= accounts.iterator();
			while(iterator.hasNext()) {
				Account account=iterator.next();
				double balance=0;
				double crAmt=0,deAmt=0;
				account.setUpdateBalance(0);
				
				if(crMap.get(account) ==null)
					crAmt=0;
				else
					crAmt=crMap.get(account);
				

				if( deMap.get(account) ==null)
					deAmt=0;
				else
					deAmt= deMap.get(account);
				
				
				
				balance=account.getOpeningBalance() +
						crAmt-deAmt;
				
				account.setUpdateBalance(balance);
				
			}
			return accounts;
			
			
	}
	@Override
	public List<Account> getAllAccounts() {
		return bankDao.getAllAccounts();
	}
	@Override
	public void fundTransfer(Transaction transaction1) {
		bankDao.fundTransfer(transaction1);
		
	}
	@Override
	public List<Transaction> getTransactions(Date d1, Date d2) {
		return bankDao.getTransactions(d1,d2);
	}
	
}
