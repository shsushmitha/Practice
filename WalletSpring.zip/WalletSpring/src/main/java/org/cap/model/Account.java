package org.cap.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.UniqueConstraint;

@Entity
public class Account {
	@Id
private int accountId;
private long accountNo;
private char accountType;
private double openingBalance;
private double openingDate;
private int custId;
private String status;
public Account() {

}
public Account(int accountId, long accountNo, char accountType, double openingBalance, double openingDate, int custId,
		String status) {
	super();
	this.accountId = accountId;
	this.accountNo = accountNo;
	this.accountType = accountType;
	this.openingBalance = openingBalance;
	this.openingDate = openingDate;
	this.custId = custId;
	this.status = status;
}
public int getAccountId() {
	return accountId;
}
public void setAccountId(int accountId) {
	this.accountId = accountId;
}
public long getAccountNo() {
	return accountNo;
}
public void setAccountNo(long accountNo) {
	this.accountNo = accountNo;
}
public char getAccountType() {
	return accountType;
}
public void setAccountType(char accountType) {
	this.accountType = accountType;
}
public double getOpeningBalance() {
	return openingBalance;
}
public void setOpeningBalance(double openingBalance) {
	this.openingBalance = openingBalance;
}
public double getOpeningDate() {
	return openingDate;
}
public void setOpeningDate(double openingDate) {
	this.openingDate = openingDate;
}
public int getCustId() {
	return custId;
}
public void setCustId(int custId) {
	this.custId = custId;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
@Override
public String toString() {
	return "Account [accountId=" + accountId + ", accountNo=" + accountNo + ", accountType=" + accountType
			+ ", openingBalance=" + openingBalance + ", openingDate=" + openingDate + ", custId=" + custId + ", status="
			+ status + "]";
}




}
