package org.cap.model;

import java.util.Date;

public class Transaction {
private int transactionId;
private Date transactionDate;
private char transactionType;
private long fromAccountNo;
private long toAccountNo;
private double amount;
private String description;
private String status;
public Transaction() {

}
public Transaction(int transactionId, Date transactionDate, char transactionType, long fromAccountNo, long toAccountNo,
		double amount, String description, String status) {
	super();
	this.transactionId = transactionId;
	this.transactionDate = transactionDate;
	this.transactionType = transactionType;
	this.fromAccountNo = fromAccountNo;
	this.toAccountNo = toAccountNo;
	this.amount = amount;
	this.description = description;
	this.status = status;
}
public int getTransactionId() {
	return transactionId;
}
public void setTransactionId(int transactionId) {
	this.transactionId = transactionId;
}
public Date getTransactionDate() {
	return transactionDate;
}
public void setTransactionDate(Date transactionDate) {
	this.transactionDate = transactionDate;
}
public char getTransactionType() {
	return transactionType;
}
public void setTransactionType(char transactionType) {
	this.transactionType = transactionType;
}
public long getFromAccountNo() {
	return fromAccountNo;
}
public void setFromAccountNo(long fromAccountNo) {
	this.fromAccountNo = fromAccountNo;
}
public long getToAccountNo() {
	return toAccountNo;
}
public void setToAccountNo(long toAccountNo) {
	this.toAccountNo = toAccountNo;
}
public double getAmount() {
	return amount;
}
public void setAmount(double amount) {
	this.amount = amount;
}
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
@Override
public String toString() {
	return "Transaction [transactionId=" + transactionId + ", transactionDate=" + transactionDate + ", transactionType="
			+ transactionType + ", fromAccountNo=" + fromAccountNo + ", toAccountNo=" + toAccountNo + ", amount="
			+ amount + ", description=" + description + ", status=" + status + "]";
}


}
