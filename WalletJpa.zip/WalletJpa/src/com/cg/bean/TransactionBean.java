package com.cg.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity

public class TransactionBean {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private int accNumber;
	private String transDetails;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getAccNumber() {
		return accNumber;
	}
	public void setAccNumber(int accNumber) {
		this.accNumber = accNumber;
	}
	public String getTransDetails() {
		return transDetails;
	}
	public void setTransDetails(String transDetails) {
		this.transDetails = transDetails;
	}
	@Override
	public String toString() {
		return "TransactionBean [accNumber=" + accNumber + ", transDetails=" + transDetails + "]";
	}
	

}
