package com.wallet1.bean;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="transaction")
public class Transaction implements Serializable{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int trid;
	private long accNumber;
	private String trtype;
	private double amount;

	public Transaction() {

	}

	public Transaction(int trid, long accNumber, String trtype, double amount) {
		super();
		this.trid = trid;
		this.accNumber = accNumber;
		this.trtype = trtype;
		this.amount = amount;
	}

	public int getTrid() {
		return trid;
	}

	public void setTrid(int trid) {
		this.trid = trid;
	}

	public long getAccNumber() {
		return accNumber;
	}

	public void setAccNumber(long accNumber) {
		this.accNumber = accNumber;
	}

	public String getTrtype() {
		return trtype;
	}

	public void setTrtype(String trtype) {
		this.trtype = trtype;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}
	

	@Override
	public String toString() {
		return "Transaction [trid=" +trid+", accNumber=" + accNumber + ", trtype=" + trtype + ", amount=" + amount + "]";
	}

}
