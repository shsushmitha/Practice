package com.wallet1.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.core.ems.beans.Employee;
import com.wallet1.bean.Customer;
import com.wallet1.bean.Transaction;
import com.wallet1.db.DBConnection;
import com.wallet1.exception.WalletException;

public class WalletDaoImpl implements WalletDao {
	private EntityManager entityManager ;
	Logger logger = Logger.getRootLogger();

	public WalletDaoImpl() {
		PropertyConfigurator.configure("resources//log4j.properties");
	}

	public int login(long accNumber) throws WalletException {

			TypedQuery<Customer> query = entityManager.createQuery("SELECT pin FROM customermaster WHERE c.accnumber := caccNo", Customer.class) ;
			query.setParameter("caccNo", accNumber) ;
			int customer = query.getFirstResult();
			return customer;
			

	}

	public Customer showBalance(long accNumber) throws WalletException {
	

			TypedQuery<Customer> query = entityManager.createQuery("select balance from Customer c where c.accNumber=:caccNo", Customer.class) ;
			query.setParameter("caccNo", accNumber) ;
			Customer customer = query.getSingleResult();
			return customer;

	

	}

	public long createAccount(Customer customer) throws WalletException {
		// TODO Auto-generated method stub
		try
		{
			//id will be assigned when object is passed to persist
			entityManager.persist(customer) ;
			
			
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		
		return customer.getAccNumber();

	}

	public boolean deposit(long num, double amount) throws WalletException {

			 entityManager.find(Customer.class, num) ;
			
			//entityManager.remove(employee);
Query query = entityManager.createQuery("INSERT INTO transaction VALUES(transaction_sequence.NEXTVAL,num,amount,ttype)") ;
			
			query.setParameter("amount", amount) ;
			query.setParameter("num", num) ;
			query.setParameter("ttype", "W") ;
			
			query.executeUpdate() ;
			
			Query query1 = entityManager.createQuery("UPDATE customer SET balance = balance + amount:=camount WHERE accNumber := caccnumber") ;
			
			query1.setParameter("camount", amount) ;
			query1.setParameter("caccnumber", num) ;
			
			query1.executeUpdate() ;
			
			return true ;


	}

	public boolean withdraw(long num, double amount) throws WalletException {
		 entityManager.find(Customer.class, num) ;
			
			//entityManager.remove(employee);
Query query = entityManager.createQuery("INSERT INTO transaction VALUES(transaction_sequence.NEXTVAL,num,amount,ttype)") ;
			
			query.setParameter("amount", amount) ;
			query.setParameter("num", num) ;
			query.setParameter("ttype", "W") ;
			
			query.executeUpdate() ;
			
			Query query1 = entityManager.createQuery("UPDATE customer SET balance = balance - amount:=camount WHERE accNumber := caccnumber") ;
			
			query1.setParameter("camount", amount) ;
			query1.setParameter("caccnumber", num) ;
			
			query1.executeUpdate() ;
			
			return true ;
	}

	public boolean fundTransfer(long num, long num1, double amount) throws WalletException {
		
			 entityManager.find(Customer.class, num) ;
			 entityManager.find(Customer.class, num1) ;
				
				//entityManager.remove(employee);
	Query query = entityManager.createQuery("INSERT INTO transaction VALUES(transaction_sequence.NEXTVAL,num,amount,ttype)") ;
				
				query.setParameter("amount", amount) ;
				query.setParameter("num", num1) ;
				query.setParameter("ttype", "W") ;
				
				query.executeUpdate() ;
				
				Query query1 = entityManager.createQuery("UPDATE customer SET balance = balance + amount:=eamount WHERE accnumber := eaccnumber") ;
				
				query1.setParameter("eamount", amount) ;
				query1.setParameter("eaccnumber", num1) ;
				
				query1.executeUpdate() ;
				
	Query query2 = entityManager.createQuery("INSERT INTO transaction VALUES(transaction_sequence.NEXTVAL,num,amount,ttype)") ;
				
				query2.setParameter("amount", amount) ;
				query2.setParameter("num", num) ;
				query2.setParameter("ttype", "W") ;
				
				query2.executeUpdate() ;
				
				Query query3 = entityManager.createQuery("UPDATE customer SET balance = balance + amount:=eamount WHERE accnumber := eaccnumber") ;
				
				query3.setParameter("eamount", amount) ;
				query3.setParameter("eaccnumber", num) ;
				
				query3.executeUpdate() ;
				
				return true ;

			
	}

	public boolean printTransaction(long num) throws WalletException {
		
			Query query = entityManager.createQuery("SELECT trid, accnumber, amount, trtype FROM transaction WHERE accnumber = eaccnumber") ;
			query.setParameter("eaccnumber", num) ;
			
			query.getResultList();
	
			return true;


	}
	
	@Override
	public void startTransaction() {
		// TODO Auto-generated method stub
		entityManager.getTransaction().begin() ;
	}

	@Override
	public void commitTransaction() {
		// TODO Auto-generated method stub
		entityManager.getTransaction().commit() ;
	}

}
