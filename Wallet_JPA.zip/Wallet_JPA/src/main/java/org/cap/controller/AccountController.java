package org.cap.controller;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.cap.model.Account;
import org.cap.model.Customer;
import org.cap.model.Transaction;
import org.cap.service.AccountService;
import org.cap.service.LoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AccountController {
	@Autowired
	private LoginService loginService;

	@Autowired
	private AccountService acccountService;

	@PostMapping("/validateLogin")
	public String validateLogin(ModelMap map, @RequestParam("customerId") String customerId,
			@RequestParam("customerPwd") String customerPwd, HttpSession session) {

		Integer custId = Integer.parseInt(customerId);

		if (loginService.validateLogin(custId, customerPwd)) {
			session.setAttribute("custId", custId);
			String custName = loginService.getCustomerName(custId);
			map.put("custName", custName);

			return "main";

		}

		return "redirect:/";
	}

	@RequestMapping("/createAccount")
	public String showCreateAccountPage(ModelMap map) {

		map.put("account", new Account());
		return "createAccount";
	}

	@PostMapping("/saveAccount")
	public String saveAccountDetails(HttpSession session, @ModelAttribute("account") Account account) {
		account.setOpeningDate(new Date());
		Integer customerId = Integer.parseInt(session.getAttribute("custId").toString());
		Customer customer = new Customer();
		customer.setCustomerId(customerId);
		account.setCustomer(customer);
		account.setStatus("active");
		acccountService.createAccount(account);

		return "redirect:createAccount";
	}

	@RequestMapping("/showBalance")
	public String showBalanceDetails(ModelMap map,
			HttpSession session) {
		
		Integer custId= Integer.parseInt(session.getAttribute("custId").toString());
		List<Account> accounts= acccountService.getAllAccounts(custId);
		
		map.put("accounts", accounts);
		
		return "showBalance";
	}

	@RequestMapping("/deposit")
	public String showDepositPage() {
		return "deposit";
	}

	@RequestMapping("/withdraw")
	public String showWithdrawPage() {
		return "withdraw";
	}

	@RequestMapping("/fundTransfer")
	public String showFundTransferPage() {
		return "fundTransfer";
	}

	@RequestMapping("/tranSummary")
	public String showTransactionPage() {
		return "tranSummary";
	}

	@RequestMapping("/logout")
	public String showLogoutPage(HttpSession session) {
		session.invalidate();
		return "redirect:/";
	}

	@RequestMapping("/currentAccount")
	public String showCurrentPage() {
		return "currentAccount";
	}

	@RequestMapping("/savingsAccount")
	public String showSavingsPage() {
		return "savingsAccount";
	}

	@RequestMapping("/rd")
	public String showRdPage() {
		return "rd";
	}

	@RequestMapping("/fd")
	public String showFdPage() {
		return "fd";
	}

}
