package recordUpdate;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	@Given("^the end date has not expired$")
	public void the_end_date_has_not_expired() throws Throwable {
	   
	}

	@When("^I enter a valid location$")
	public void i_enter_a_valid_location() throws Throwable {
	 
	}

	@Then("^it is assigned to an equipment record$")
	public void it_is_assigned_to_an_equipment_record() throws Throwable {
	    
	}

	@When("^I enter location which is invalid$")
	public void i_enter_location_which_is_invalid() throws Throwable {
	   
	}

	@Then("^throw 'Invalid location' error message$")
	public void throw_Invalid_location_error_message() throws Throwable {
	    
	}

	@When("^I enter user who is valid$")
	public void i_enter_user_who_is_valid() throws Throwable {
	   
	}

	@When("^I enter user who is invalid$")
	public void i_enter_user_who_is_invalid() throws Throwable {
	   
	}

	@Then("^throw 'Invalid user' error message$")
	public void throw_Invalid_user_error_message() throws Throwable {
	   
	}



}
