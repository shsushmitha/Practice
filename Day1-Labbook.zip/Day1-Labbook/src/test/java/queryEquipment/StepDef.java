package queryEquipment;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	@Given("^system has an equipment tag$")
	public void system_has_an_equipment_tag() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Given("^user makes a query using it$")
	public void user_makes_a_query_using_it() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^user must have the ability to query for an equipment$")
	public void user_must_have_the_ability_to_query_for_an_equipment() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Given("^user has a need for query and storage consistency$")
	public void user_has_a_need_for_query_and_storage_consistency() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^it is all numeric$")
	public void it_is_all_numeric() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^has (\\d+) characters$")
	public void has_characters(int arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^the equipment tag will remove any blanks or dashes$")
	public void the_equipment_tag_will_remove_any_blanks_or_dashes() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^it will check for text 'AD'$")
	public void it_will_check_for_text_AD() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^the text 'AD' is found in position (\\d+) and (\\d+) of the character string$")
	public void the_text_AD_is_found_in_position_and_of_the_character_string(int arg1, int arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^it will be removed from Equipment Tag$")
	public void it_will_be_removed_from_Equipment_Tag() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^if the length is less than (\\d+) character$")
	public void if_the_length_is_less_than_character(int arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^it will be padded with leading zeroes$")
	public void it_will_be_padded_with_leading_zeroes() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^system has to manipulate sequence number input$")
	public void system_has_to_manipulate_sequence_number_input() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^the system must use the most recent rules$")
	public void the_system_must_use_the_most_recent_rules() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^it should be contained within the authorized document$")
	public void it_should_be_contained_within_the_authorized_document() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Given("^user has the ability to query$")
	public void user_has_the_ability_to_query() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Given("^user has a Machine Id$")
	public void user_has_a_Machine_Id() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^user must able to query for an equipment using that id$")
	public void user_must_able_to_query_for_an_equipment_using_that_id() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Given("^user has a User Id$")
	public void user_has_a_User_Id() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Given("^user have a location$")
	public void user_have_a_location() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^it is a valid location from the list$")
	public void it_is_a_valid_location_from_the_list() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^user must able to query for an equipment using that location\\.$")
	public void user_must_able_to_query_for_an_equipment_using_that_location() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

}
