package restrictUpdate;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	@Given("^User logs in$")
	public void user_logs_in() throws Throwable {
	    
	}

	@When("^users exist in Inventory personnel$")
	public void users_exist_in_Inventory_personnel() throws Throwable {
	   
	}

	@Then("^update record$")
	public void update_record() throws Throwable {
	   
	}

	@Then("^if user doesnt exist in Inventory personnel$")
	public void if_user_doesnt_exist_in_Inventory_personnel() throws Throwable {
	
	}

	@Then("^throw 'Not an authorized user' error message$")
	public void throw_Not_an_authorized_user_error_message() throws Throwable {
	    
	}

	@When("^users exist in equipment auditors$")
	public void users_exist_in_equipment_auditors() throws Throwable {
	    
	}

	@Then("^if user doesnt exist in equipment auditors$")
	public void if_user_doesnt_exist_in_equipment_auditors() throws Throwable {
	    
	}

	@When("^users exist in service personnel$")
	public void users_exist_in_service_personnel() throws Throwable {
	  
	}

	@Then("^if user doesnt exist in service personnel$")
	public void if_user_doesnt_exist_in_service_personnel() throws Throwable {
	
	}

	@When("^users exist in maintenance personal$")
	public void users_exist_in_maintenance_personal() throws Throwable {
	    
	}

	@Then("^if user doesnt exist in maintenance personal$")
	public void if_user_doesnt_exist_in_maintenance_personal() throws Throwable {
	    
	}

	@When("^users exist in Equipment Tracking personnel$")
	public void users_exist_in_Equipment_Tracking_personnel() throws Throwable {
	   
	}

	@Then("^if user doesnt exist in Equipment Tracking personnel$")
	public void if_user_doesnt_exist_in_Equipment_Tracking_personnel() throws Throwable {
	    
	}


}
