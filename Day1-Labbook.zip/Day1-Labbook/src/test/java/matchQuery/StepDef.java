package matchQuery;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	@Given("^an Inventory Personnel named ?A?$")
	public void an_Inventory_Personnel_named_A() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Given("^an Equipment auditor named ?B?$")
	public void an_Equipment_auditor_named_B() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Given("^a Service Personnel named ?C?$")
	public void a_Service_Personnel_named_C() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Given("^a Maintenance Personal named ?D?$")
	public void a_Maintenance_Personal_named_D() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Given("^an Equipment Tracking Personnel named ?E?$")
	public void an_Equipment_Tracking_Personnel_named_E() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Given("^the above mentioned users along with other users are named ?F?$")
	public void the_above_mentioned_users_along_with_other_users_are_named_F() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Given("^I am logged in as F$")
	public void i_am_logged_in_as_F() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^I try to access Equipment Tag$")
	public void i_try_to_access_Equipment_Tag() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^I should see the Equipment Tag value$")
	public void i_should_see_the_Equipment_Tag_value() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^I try to access the Quantity$")
	public void i_try_to_access_the_Quantity() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^I should see the Quantity value$")
	public void i_should_see_the_Quantity_value() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^I try to access the Seq\\. Number$")
	public void i_try_to_access_the_Seq_Number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^I should see the Seq\\. Number value$")
	public void i_should_see_the_Seq_Number_value() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^I try to access the User Id$")
	public void i_try_to_access_the_User_Id() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^I should see the User Id value$")
	public void i_should_see_the_User_Id_value() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^I try to access the Location$")
	public void i_try_to_access_the_Location() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^I should see the Location value$")
	public void i_should_see_the_Location_value() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^I try to access the Equipment Type$")
	public void i_try_to_access_the_Equipment_Type() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^I should see the Equipment Type value$")
	public void i_should_see_the_Equipment_Type_value() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

}
