package org.cap.model;

public class User {
private String uname;

}
