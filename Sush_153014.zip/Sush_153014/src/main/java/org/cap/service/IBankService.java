package org.cap.service;

import java.util.Date;
import java.util.List;
import org.cap.model.Account;
import org.cap.model.Transaction;



public interface IBankService {
	public boolean validate(int userName, String password);

	public void createAccount(Account account);

	public String getUserName();

	public List<Long> getAccountNumbers();

	public void depWithAccount(Transaction transaction);
	
	
	
	public List<Account> getAllAccountsOfCustomer();
	public	List<Account> getAccountWithBalance();

	public List<Account> getAllAccounts();

	public void fundTransfer(Transaction transaction1);

	public List<Transaction> getTransactions(Date d1, Date d2);

	
	}
