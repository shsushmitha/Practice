package com.capgemini.core.ems.model;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.apache.log4j.Logger;

import com.capgemini.core.ems.beans.Employee;
import com.capgemini.core.ems.exceptions.EMSException;
import com.capgemini.core.ems.util.DBUtil;
import com.capgemini.core.ems.util.JPAUtil;

public class EmployeeDAOImpl implements EmployeeDAO {

	private EntityManager entityManager ;
	
	
	

	public EmployeeDAOImpl() {
		entityManager = JPAUtil.getEntityManager();
	}

	@Override
	public int addEmployee(Employee employee) throws EMSException {
		// TODO Auto-generated method stub
		
		try
		{
			//id will be assigned when object is passed to persist
			entityManager.persist(employee) ;
			
			
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		
		return employee.getId() ;
	}

	@Override
	public Employee getEmployee(int id) throws EMSException {
		// TODO Auto-generated method stub
		
//		Employee employee = entityManager.find(Employee.class, id) ;
		
		TypedQuery<Employee> query = entityManager.createQuery("select e from Employee e where e.id=:eid", Employee.class) ;
		query.setParameter("eid", id) ;
		Employee employee = query.getSingleResult();
		return employee;
	}
	@Override
	public Employee removeEmployee(int id) throws EMSException {
		// TODO Auto-generated method stub
		
		Employee employee = entityManager.find(Employee.class, id) ;
		
		//entityManager.remove(employee);
		
		Query query = entityManager.createQuery("Delete from Employee e where e.id=:eid") ;
		
		query.setParameter("eid", id) ;
		
		query.executeUpdate() ;
		
		return employee ;
		
	}
	@Override
	public void updateEmployee(Employee employee) throws EMSException {
		// TODO Auto-generated method stub
		
		Query query = entityManager.createQuery(
				"update Employee e set "
				+ "e.name=:e_name,"
				+ "e.salary=:e_salary,"
				+ "e.department=:e_department,"
				+ "e.dateOfBirth=:e_dateOfBirth,"
				+ "e.dateOfJoining=:e_dateOfJoining "
				+ "where e.id=:e_id");
		query.setParameter("e_name", employee.getName()) ;
		query.setParameter("e_salary", employee.getSalary()) ;
		query.setParameter("e_department", employee.getDepartment()) ;
		query.setParameter("e_dateOfBirth", employee.getDateOfBirth()) ;
		query.setParameter("e_dateOfJoining", employee.getDateOfJoining()) ;
		query.setParameter("e_id", employee.getId());
		
		query.executeUpdate() ;
		
		
		//entityManager.merge(employee) ;

       
	
	}

	@Override
	public List<Employee> getAllEmployees() throws EMSException {
		// TODO Auto-generated method stub
		
		TypedQuery<Employee> query = entityManager.createQuery("select employee from Employee employee",Employee.class) ;
	
		return query.getResultList();
	}

	@Override
	public void startTransaction() {
		// TODO Auto-generated method stub
		entityManager.getTransaction().begin() ;
	}

	@Override
	public void commitTransaction() {
		// TODO Auto-generated method stub
		entityManager.getTransaction().commit() ;
	}

}
