package page;

import java.util.Date;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class PaymentPageBean {
WebDriver driver;
	
	@FindBy(name="chname",how=How.NAME)
	private WebElement chname;
	
	@FindBy(name="cardNo")
	private WebElement cardNo;
	
	@FindBy(name="cvv")
	private WebElement cvv;
	
	@FindBy(name="expdate")
	private WebElement expdate;
	
	@FindBy(id="pay")
	private WebElement pay;
@FindBy(xpath="/html/body/center/h1")
	
	private WebElement pageheading;
	public PaymentPageBean(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	public String getPageTitle1() {
		//return driver.findElement(pageheading).getText();
		return pageheading.getText();
	}
	public void setChname(String cardholdername) {
		chname.sendKeys(cardholdername);
	}

	public void setCardNo(String cardNum) {
		cardNo.sendKeys(cardNum);
	}

	public void setCvv(String cvvNum) {
		cvv.sendKeys(cvvNum);
	}

	public void setExpdate(String expirydate) {
		expdate.sendKeys(expirydate);
	}
/*	public void setExpdate(CharSequence[] expiryDate) {
		expdate.sendKeys(expiryDate);
	}*/
	public void setPay() {
		pay.submit();
	}
	
	public void payment_Page(String chname,String cardNo,String cvv,String expdate) {
		this.setChname(chname);
		this.setCardNo(cardNo);
		this.setCvv(cvv);
		this.setExpdate(expdate);
		this.setPay();
	}

}
