package com.cg.clinic.bean;

import java.time.LocalDate;


public class Clinic {
private int patientId;
private String name;
private int age;
private String phone;
private String description;
private LocalDate consaltationDate;
public int getPatientId() {
	return patientId;
}
public void setPatientId(int patientId) {
	this.patientId = patientId;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
public String getPhone() {
	return phone;
}
public void setPhone(String phone) {
	this.phone = phone;
}
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}
public LocalDate getConsaltationDate() {
	return consaltationDate;
}
public void setConsaltationDate(LocalDate consaltationDate) {
	this.consaltationDate = consaltationDate;
}

public Clinic(int patientId, String name, int age, String phone, String description, LocalDate consaltationDate) {
	super();
	this.patientId = patientId;
	this.name = name;
	this.age = age;
	this.phone = phone;
	this.description = description;
	this.consaltationDate = consaltationDate;
}

public Clinic() {
	
}
/*@Override
public String toString() {
	return "Clinic [patientId=" + patientId + ", name=" + name + ", age=" + age + ", phone=" + phone + ", description="
			+ description + ", consaltationDate=" + consaltationDate + "]";
}*/

}
