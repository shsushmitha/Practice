package com.cg.clinic.ui;

import java.time.LocalDate;
import java.util.Scanner;

import com.cg.clinic.bean.Clinic;
import com.cg.clinic.exception.ClinicException;
import com.cg.clinic.service.ClinicService;
import com.cg.clinic.service.ClinicserviceImpl;

public class Client {
	ClinicService clinicservice = new ClinicserviceImpl();
	Scanner scan = new Scanner(System.in);

	public static void main(String[] args) {
		String option = null;
		Client c = new Client();
		while (true) {
			System.out.println("=======Clinic Management System========");
			System.out.println("1. Add patient information");
			System.out.println("2. Search patient by Id");
			System.out.println("3. Exit");
			System.out.println("Enter your choice:");
			option = c.scan.nextLine();
			switch (option) {
			case "1":
				c.addPatient();
				break;
			case "2":
				c.getPatientById();
				break;
			case "3":
				System.exit(0);
			default:
				System.err.println("Invalid Option Choose from 1 to 6");
				System.out.println();
				break;
			}
		}

	}

	public void addPatient() {
		Clinic c = new Clinic();
		/*System.out.println("Enter patient Id:");
		c.setPatientId(Integer.parseInt(scan.nextLine()));*/
		System.out.println("Enter the name of the Patient:");
		c.setName(scan.nextLine());
		System.out.println("Enter Patient Age:");
		c.setAge(Integer.parseInt(scan.nextLine()));
		System.out.println("Enter Patient phone number:");
		c.setPhone(scan.nextLine());
		System.out.println("Enter description:");
		c.setDescription(scan.nextLine());
		try {
			boolean result = clinicservice.validatePatient(c);

			if (result) {
				c.setConsaltationDate(LocalDate.now());
				int ret = clinicservice.addPatient(c);
				System.out.println("Patient information stored successfully for " + ret);
			}
		} catch (ClinicException e) {
			System.out.println();
			System.err.println("An error occured" + e.getMessage());
			System.out.println();
		}

	}
	
	public void getPatientById() {
		System.out.println("Enter Patient Id");
		String id = scan.nextLine();
		try {
			int pid=Integer.parseInt(id);
			Clinic cli=clinicservice.getPatientById(pid);
			//System.out.println("Patient id:"+cli.getPatientId());
			System.out.println("Name of the Patient: "+cli.getName());
			System.out.println("Age: "+cli.getAge());
			System.out.println("Phone Number: "+cli.getPhone());
			System.out.println("Description: "+cli.getDescription());
			System.out.println("Consultation Date: "+cli.getConsaltationDate());
			
			}
		catch(ClinicException e) {
			System.err.println("There is no patient with this id");
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}

}
