package com.cg.clinic.dao;

import com.cg.clinic.bean.Clinic;
import com.cg.clinic.exception.ClinicException;


public interface ClinicDao {
	int addPatient(Clinic cli) throws ClinicException;
	Clinic getPatientById(int id) throws ClinicException;
}
