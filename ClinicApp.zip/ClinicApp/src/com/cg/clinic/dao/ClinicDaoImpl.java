package com.cg.clinic.dao;

import java.util.HashMap;
import java.util.Optional;

import com.cg.clinic.bean.Clinic;
import com.cg.clinic.db.ClinicDB;
import com.cg.clinic.exception.ClinicException;


public class ClinicDaoImpl implements ClinicDao {
	static HashMap<Integer, Clinic> cliMap = ClinicDB.getClinicMap();

	@Override
	public int addPatient(Clinic cli) throws ClinicException {
		// TODO Auto-generated method stub
		try {
			if(cliMap.size()==0) {
				cli.setPatientId(5001);
			}
			else {
				Optional<Integer> id=cliMap.keySet().stream().max((x,y)->(x>y)?1:(x<y)?-1:0);
				int reqId = id.get()+1;
				cli.setPatientId(reqId);
			}
			Clinic c = cliMap.get(cli.getPatientId());
			if (c != null) {
				throw new ClinicException("Patient with id" + cli.getPatientId() + "already exists");
			} else {
				cliMap.put(cli.getPatientId(), cli);
			}

		} catch (Exception ex) {
			throw new ClinicException(ex.getMessage());
		}
		return cli.getPatientId();
	}

	@Override
	public Clinic getPatientById(int id) throws ClinicException {
		// TODO Auto-generated method stub
		try {
			Clinic cli=cliMap.get(id);
			if(cli==null) {
				throw new ClinicException("Patient with id "+id+" is available in database");
			}
			return cli;
		}
		catch (Exception ex) {
			throw new ClinicException(ex.getMessage());
		}

	}

}
