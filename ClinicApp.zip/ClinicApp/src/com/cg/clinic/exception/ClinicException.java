package com.cg.clinic.exception;

public class ClinicException extends Exception {

	public ClinicException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ClinicException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
