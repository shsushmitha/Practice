package com.cg.clinic.db;

import java.util.HashMap;

import com.cg.clinic.bean.Clinic;


public class ClinicDB {
private static HashMap<Integer,Clinic> cliMap=new HashMap<Integer,Clinic>();

public static HashMap<Integer, Clinic> getClinicMap() {
	return cliMap;
}

}
