package com.cg.clinic.service;

import com.cg.clinic.bean.Clinic;
import com.cg.clinic.dao.ClinicDao;
import com.cg.clinic.dao.ClinicDaoImpl;
import com.cg.clinic.exception.ClinicException;


public class ClinicserviceImpl implements ClinicService {
ClinicDao clinicDao=new ClinicDaoImpl();
	@Override
	public int addPatient(Clinic cli) throws ClinicException {
		// TODO Auto-generated method stub
		return clinicDao.addPatient(cli);
	}
	@Override
	public boolean validatePatient(Clinic cli) throws ClinicException {
		// TODO Auto-generated method stub
		if (validateName(cli.getName()) && validatePhone(cli.getPhone())) {
			return true;
		}
		return false;
	}
	
	private boolean validateName(String name) throws ClinicException{
		if (name.isEmpty() || name == null) {
			throw new ClinicException("Employee Name cannot be empty");
		} else {
			if (!name.matches("[A-Z][A-Za-z ]{2,}")) {
				throw new ClinicException(
						"Name should start with a Capital letter followed by minimum of 2 alphabets");
			}
		}
		return true;
	}

	private boolean validatePhone(String phone) throws ClinicException {

		if (phone.isEmpty() || phone == null) {
			throw new ClinicException("Mobile Number is mandatory");

		} else {
			if (!phone.matches("\\d{10}")) {
				throw new ClinicException("Mobile number should contain only 10 digits");
			}
		}
		return true;
	}
	@Override
	public Clinic getPatientById(int id) throws ClinicException {
		// TODO Auto-generated method stub
		return clinicDao.getPatientById(id);
	}

}
