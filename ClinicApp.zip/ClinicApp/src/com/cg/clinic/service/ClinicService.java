package com.cg.clinic.service;

import com.cg.clinic.bean.Clinic;
import com.cg.clinic.exception.ClinicException;

public interface ClinicService {
	int addPatient(Clinic cli) throws ClinicException;
	boolean validatePatient(Clinic cli) throws ClinicException;
	Clinic getPatientById(int id) throws ClinicException;
}
