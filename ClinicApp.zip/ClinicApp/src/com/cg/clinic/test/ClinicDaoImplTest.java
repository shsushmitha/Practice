package com.cg.clinic.test;

import static org.junit.Assert.assertNotNull;
import org.junit.Test;

import com.cg.clinic.bean.Clinic;
import com.cg.clinic.dao.ClinicDao;
import com.cg.clinic.dao.ClinicDaoImpl;
import com.cg.clinic.exception.ClinicException;

public class ClinicDaoImplTest {
	ClinicDao dao=new ClinicDaoImpl();

	@Test
	public void testAddPatient() {
		Clinic cli=new Clinic();
		cli.setPatientId(5000);
		cli.setName("Preethi");
		cli.setAge(24);
		cli.setPhone("9999999999");
		cli.setDescription("cough");
				try {
			dao.addPatient(cli);
			Clinic c= dao.getPatientById(5000);
			assertNotNull(c);
		} catch (ClinicException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
	}

	@Test
	public void testGetPatientById() {
		try {
			Clinic cli=dao.getPatientById(5001);
			assertNotNull(cli);
			
		} catch (ClinicException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
	}

}
