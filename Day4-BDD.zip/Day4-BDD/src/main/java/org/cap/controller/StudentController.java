package org.cap.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class StudentController {
				
				@RequestMapping("/")
				public String studentRegistrationForm() {
					return "studentDetails";
					
				}
				
				@RequestMapping("/payment")
				public String personalDetails() {
					return "paymentDetails";
					
				}
}
