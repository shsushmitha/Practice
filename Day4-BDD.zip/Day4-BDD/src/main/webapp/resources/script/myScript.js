/*
function validateForm() {
    
	var fname=studform.firstname.value;
	var lname=studform.lastname.value;
	
    if (fname == ""|| fname==null) {
        alert("First Name must be filled out");
        return false;
    }
	if (!fname.matches("[A-Z][A-Za-z ]")) {
		alert("Name should start with a Capital letter followed by minimum of 2 alphabets");
		return false;
	}
    if (lname == ""|| lname==null) {
        alert("Last Name must be filled out");
        return false;
    }
    if (!lname.matches("[A-Z][A-Za-z ]")) {
		alert("Name should start with a Capital letter followed by minimum of 2 alphabets");
		return false;
	}
    
    
}
 */

function validateForm() {
	var firstname = studform.firstname.value;
	var lastName = studform.lastname.value;
	var address = studform.address.value;
	var city = studform.city.value;
	var state = studform.state.value;
	var gender = studform.gender.value;
	var course = studform.course.value;
	var mobilenum = studform.mobile.value;
	var validname = /^[A-Z][a-zA-Z]{2,}$/;
	//var validmobileNo = /^\\d{10}$/;
	var flag = false;
	/*var radios = document.getElementsByName("gender");
    var formValid = false;
    var i = 0;
    while (!formValid && i < radios.length) {
        if (radios[i].checked) formValid = true;
        i++;        
    }

    if (!formValid) alert("Must check some option!");
    return formValid;*/
	
	 /*var gender = document.getElementsByName('gender');
     var genValue = false;*/

  
	if (firstname == "" || firstname == null) {
		alert("Please enter FirstName");
	} else if (validname.test(firstname) == false) {
		alert("Please enter a vaild Firstname");
	} else if (lastName == "" || lastName == null) {
		alert("Please enter LastName");
	} else if (validname.test(lastName) == false) {
		alert("Please enter a vaild Lastname");
	} else if (address == "" || address == null) {
		alert("Please enter address");
	} else if (city == "" || city == null) {
		alert("Please enter city");
	} else if (state == "" || state == null) {
		alert("Please enter state");
	} else if (mobile == "" || mobile == null) {
		alert("Please enter mobile number");
	} 
	/*else if (validmobileNo.test(mobile) == false) {
		alert("Please enter a vaild mobile number");
	} */
	else {
		flag = true;
		alert("Your details are successfully saved");
	}
	return flag;

}

function validatePaymentForm() {
	var chname = payform.chname.value;
	var cardNo = payform.cardNo.value;
	var cvv = payform.cvv.value;
	var expdate = payform.expdate.value;
	var validname = /^[A-Z]{3,}$/;
	var validcardNo = /^\d{16}$/;
	var validcvvNo = /^\d{3}$/;
	var dateformat = /^(0?[1-9]|1[012])[\/]\d{4}$/;
	var flag = false;
	if (chname == "" || chname == null) {
		alert("Please enter Card holder name");
	} else if (validname.test(chname) == false) {
		alert("Please enter a vaild Card holder name");
	} else if (cardNo == "" || cardNo == null) {
		alert("Please enter credit/debit card number");
	} else if (validcardNo.test(cardNo) == false) {
		alert("Please enter a vaild card number");
	} else if (cvv == "" || cvv == null) {
		alert("Please enter cvv number");
	} else if (validcvvNo.test(cvv) == false) {
		alert("Please enter a vaild cvv number");
	} else if (expdate == "" || expdate == null) {
		alert("Please enter expiry date");
	} else if (dateformat.test(expdate) == false) {
		alert("Please enter a vaild date mm/yy");
	} else {
		flag = true;
		alert("Your payment is successfully done");
	}
	return flag;
}
