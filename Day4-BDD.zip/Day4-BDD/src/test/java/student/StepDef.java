package student;

import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.timeout;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import page.LoginPageBean;
import page.PaymentPageBean;

public class StepDef {
	
	private WebDriver driver;
	//private WebElement element;
	private LoginPageBean loginPageBean;
	private PaymentPageBean paymentPageBean;
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");

		 driver=new ChromeDriver();
		 driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			
			loginPageBean=new LoginPageBean(driver);
			paymentPageBean=new PaymentPageBean(driver);
	}
	@Given("^student details form$")
	public void student_details_form() throws Throwable {
		driver.get("http://localhost:8089/Day4-BDD/");
	}

	@When("^valid student details are entered$")
	public void valid_student_details_are_entered() throws Throwable {
		loginPageBean.goTo_NextPage("Sush", "sami", "21/23", "893928680");
		
	}

	@Then("^navigate to payment page$")
	public void navigate_to_payment_page() throws Throwable {
		//String url=driver.getCurrentUrl();
		//assertTrue(url.equals("http://localhost:8089/Day4-BDD/"));
	   driver.switchTo().alert().accept();
	   driver.close();
		//driver.navigate().to("http://localhost:8089/Day4-BDD/payment");
		/*paymentPageBean.payment_Page("SUSH", "1234123412341234", "123", "1212");
		driver.switchTo().alert().accept();*/
	   
	}
	
	/*@When("^valid payment details are entered$")
	public void valid_payment_details_are_entered() throws Throwable {
		paymentPageBean.payment_Page("SUSH", "1234123412341234", "123", "1212");
	}

	@Then("^show popup 'registration done'$")
	public void show_popup_registration_done() throws Throwable {
		driver.switchTo().alert().accept();
	}*/
	
	@Given("^payment details form$")
	public void payment_details_form() throws Throwable {
		driver.get("http://localhost:8089/Day4-BDD/payment");
	}

	@When("^valid payment details are entered$")
	public void valid_payment_details_are_entered() throws Throwable {
		paymentPageBean.payment_Page("SUSH", "1234123412341234", "123", "12/2018");
	}

	@Then("^show popup 'registration done'$")
	public void show_popup_registration_done() throws Throwable {
		//driver.manage().timeouts().wait(10);
		driver.switchTo().alert().accept();
	}



	


}
