package page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class LoginPageBean {
	WebDriver driver;
	
	@FindBy(name="firstname",how=How.NAME)
	private WebElement firstname;
	
	@FindBy(name="lastname")
	private WebElement lastname;
	
	@FindBy(name="address")
	private WebElement address;
	
	@FindBy(name="city")
	private WebElement city;
	
	@FindBy(name="state")
	private WebElement state;
	
	@FindBy(name="gender")
	private WebElement gender;
	
	@FindBy(name="course")
	private WebElement course;
	
	@FindBy(name="mobile")
	private WebElement mobile;
	
	@FindBy(id="login")
	private WebElement Login;
	
/*	@FindBy(xpath="//*[@id=\"mainCnt\"]/h1")
	private WebElement pageheading;*/
	
	
	public LoginPageBean(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

	

	public void setFirstName(String fname) {
		firstname.sendKeys(fname);
	}


	public void setLastname(String lname) {
		lastname.sendKeys(lname);
	}

	public void setAddress(String addr) {
		address.sendKeys(addr);
	}


	/*public void setCity(String cityname) {
		city.sendKeys(cityname);
	}

	public void setState(String statename) {
		state.sendKeys(statename);
	}

	public void setGender(String gen) {
		gender.sendKeys(gen);
	}

	public void setCourse(String coursename) {
		course.sendKeys(coursename);
	}
*/
	
	public void setCity() {
		city.isSelected();
	}

	public void setState() {
		state.isSelected();
	}

	public void setGender() {
		gender.isSelected();
	}

	public void setCourse() {
		course.isSelected();
	}

	public void setMobile(String mobilenum) {
		mobile.sendKeys(mobilenum);
	}

	public void setLogin() {
		Login.submit();
	}
	
	public void goTo_NextPage(String fname,String lname,String addr, String mobile) {
		this.setFirstName(fname);
		this.setLastname(lname);
		this.setAddress(addr);
		//this.setCity(city);
		//this.setState(state);
		//this.setGender(gender);
		//this.setCourse(course);
		this.setMobile(mobile);
		this.setCity();
		this.setState();
		this.setCourse();
		this.setGender();
		this.setLogin();
	}
	

	
	
	/*public void loginTo_NextPage(String userName,
			String password) {
		this.setUserName(userName);
		
		this.setUserPwd(password);
		this.setSubmitLogin();
	}*/

}
