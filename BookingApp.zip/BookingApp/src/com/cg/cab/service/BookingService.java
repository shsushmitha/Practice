package com.cg.cab.service;

import com.cg.cab.bean.CabRequest;
import com.cg.cab.exception.BookingException;

public interface BookingService {
	boolean validateRequest(CabRequest request) throws BookingException;
	public int addRequest(CabRequest request) throws BookingException;
	public CabRequest getRequest(int requestId) throws BookingException;
}
