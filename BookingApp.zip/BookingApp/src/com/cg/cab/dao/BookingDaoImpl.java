package com.cg.cab.dao;

import java.util.HashMap;
import java.util.Optional;

import com.cg.cab.bean.CabRequest;
import com.cg.cab.db.BookingDB;
import com.cg.cab.exception.BookingException;

public class BookingDaoImpl implements BookingDao {
	static HashMap<Integer,CabRequest> requestMap= BookingDB.getBookingMap();
	@Override
	public int addRequest(CabRequest request) throws BookingException {
		try {
			if(requestMap.size()==0) {
				request.setRequestId(1001);
			}
			else {
				Optional<Integer> id=requestMap.keySet().stream().max((x,y)->(x>y)?1:(x<y)?-1:0);
				int reqId = id.get()+1;
				request.setRequestId(reqId);
			}
		requestMap.put(request.getRequestId(), request);
		return request.getRequestId();
		}
		catch(Exception ex) {
			throw new BookingException(ex.getMessage());
		}
		
	}
	@Override
	public CabRequest getRequest(int requestId) throws BookingException {
		try {
			CabRequest request=requestMap.get(requestId);
			if(request==null) {
				throw new BookingException("Invalid request id");
			}
			return request;
		}
		catch(Exception ex) {
			throw new BookingException(ex.getMessage());
		}
		
	}

}
