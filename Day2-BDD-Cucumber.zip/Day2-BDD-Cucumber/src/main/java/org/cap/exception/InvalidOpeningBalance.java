package org.cap.exception;

public class InvalidOpeningBalance extends Exception {
	public InvalidOpeningBalance(String msg) {
		super(msg);
	}
}
