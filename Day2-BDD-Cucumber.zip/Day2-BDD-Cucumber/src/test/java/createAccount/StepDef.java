package createAccount;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import org.cap.model.Account;
import org.cap.model.Address;
import org.cap.model.Customer;
import org.cap.service.AccountServiceImpl;
import org.cap.service.IAccountService;

import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	
private Customer customer;
private double openingBalance;
private IAccountService accountService;
@Before
public void setup() {
	customer = new Customer();
	openingBalance=1000;
	accountService= new AccountServiceImpl();

}
	@Given("^customer details$")
	public void customer_details() throws Throwable {
		customer.setFirstName("sush");
		customer.setLastName("sh");
		Address address= new Address();
		address.setDoorNo("21/5");
		address.setCity("Chennai");
		customer.setAddress(address);
	}

	@When("^Valid Customer$")
	public void valid_Customer() throws Throwable {
	    assertNotNull(customer);
	}

	@When("^valid opening balance$")
	public void valid_opening_balance() throws Throwable {
	    assertTrue(openingBalance>=500);
	}

	@Then("^create new Account$")
	public void create_new_Account() throws Throwable {
		Account account=accountService.creatAccount(customer, openingBalance);
	    assertNotNull(customer);
	    assertEquals(openingBalance, account.getOpeningBalance(),0.0);
	    assertEquals(1, account.getAccountNo());;
	}
	
	@Given("^Customer details$")
	public void customer_details1() throws Throwable {
		customer=null;
	} 
	@When("^Invalid Customer$")
	public void invalid_Customer() throws Throwable {
	    assertNull(customer);
	}

	@Then("^throw 'Invalid Customer' error message$")
	public void throw_Invalid_Customer_error_message() throws Throwable {
	   try {
		 accountService.creatAccount(customer, 3000);  
	   }
	   catch(Exception e) {
		   
	   }
	}
	
	@Given("^Customer details and opening balance$")
	public void customer_details_and_opening_balance() throws Throwable {
	    openingBalance=100;
	}

	@When("^Invalid opening balance$")
	public void invalid_opening_balance() throws Throwable {
	    assertTrue(openingBalance<500);
	}

	@Then("^throw 'Insufficient Balance' error message$")
	public void throw_Insufficient_Balance_error_message() throws Throwable {
		 try {
			 accountService.creatAccount(customer, openingBalance);  
		   }
		   catch(Exception e) {
			   
		   }
	}	




}
