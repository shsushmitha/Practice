package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.cap.model.Pilot;
import org.springframework.stereotype.Repository;
@Repository("pilotDbDao")
@Transactional
public class PilotDaoDBImpl implements IPilotDao{
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public List<Pilot> getAllPilots() {
		// TODO Auto-generated method stub
		List<Pilot> pilots=entityManager.createQuery("from pilot").getResultList();
		return pilots;
	}

	@Override
	public Pilot findPilot(Integer pilotId) {
		// TODO Auto-generated method stub
		Pilot pilot=entityManager.find(Pilot.class, pilotId);
		return pilot;
	}

	@Override
	public List<Pilot> deletePilot(Integer pilotId) {
		// TODO Auto-generated method stub
		Pilot pilot=entityManager.find(Pilot.class, pilotId);
		entityManager.remove(pilot);
		return getAllPilots();
	}

	@Override
	public List<Pilot> createPilot(Pilot pilot) {
		// TODO Auto-generated method stub
		entityManager.persist(pilot);
		return getAllPilots();
		
		
	}

	@Override
	public List<Pilot> putPilot(Pilot pilotId) {
		// TODO Auto-generated method stub
		return null;
	}

/*	@Override
	public List<Pilot> putPilot(Pilot pilotId) {
		// TODO Auto-generated method stub
		Pilot pilot=entityManager.find(Pilot.class, pilotId);
		entityManager.(pilot);
		return getAllPilots();
	}*/

}
