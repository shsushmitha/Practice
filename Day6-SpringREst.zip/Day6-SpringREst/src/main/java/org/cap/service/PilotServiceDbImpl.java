package org.cap.service;

import java.util.List;

import org.cap.model.Pilot;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
@Service
@Repository("pilotDbService")
public class PilotServiceDbImpl implements IPilotService{

	@Override
	public List<Pilot> getAllPilots() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Pilot findPilot(Integer pilotId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Pilot> deletePilot(Integer pilotId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Pilot> createPilot(Pilot pilot) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Pilot> putPilot(Pilot pilotId) {
		// TODO Auto-generated method stub
		return null;
	}

}
